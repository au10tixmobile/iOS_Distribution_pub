//
//  Au10tixCore.h
//  Au10tixCore
//
//  Created by Assaf Halfon on 22/04/2021.
//  Copyright © 2021 Au10tix. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Au10tixCore.
FOUNDATION_EXPORT double Au10tixCoreVersionNumber;

//! Project version string for Au10tixCore.
FOUNDATION_EXPORT const unsigned char Au10tixCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Au10tixCore/PublicHeader.h>


